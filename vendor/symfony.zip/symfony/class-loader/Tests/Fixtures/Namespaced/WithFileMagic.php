<?php

/*
 * foo
 */

namespace Namespaced;

class WithFileMagic
{
    public function getFile()
    {
        return __FILE__;
    }
}
