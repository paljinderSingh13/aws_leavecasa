<?php

class Pearlike_FooBar
{
    public static $loaded = true;
}
