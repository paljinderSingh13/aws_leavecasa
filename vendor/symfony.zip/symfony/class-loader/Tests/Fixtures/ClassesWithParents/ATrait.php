<?php

namespace ClassesWithParents;

trait ATrait
{
}
