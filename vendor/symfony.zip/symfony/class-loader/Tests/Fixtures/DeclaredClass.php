<?php

namespace Symfony\Component\ClassLoader\Tests\Fixtures;

class DeclaredClass implements DeclaredInterface
{
}
