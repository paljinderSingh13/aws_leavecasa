# Laravel DataTables Fractal Plugin

## Change Log

### v1.0.0 - (31-AUG-2017)
- First stable release.
