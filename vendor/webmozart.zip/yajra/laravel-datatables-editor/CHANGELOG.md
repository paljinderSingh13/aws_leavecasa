# Laravel DataTables Editor CHANGELOG 

## [Unreleased]

## [v1.0.0] - 2017-12-17
- First stable release.

### Features
- DataTables Editor CRUD actions supported.
- Inline editing.
- Bulk edit & delete function.
- CRUD validation.
- CRUD pre / post events hooks.
- Artisan command for DataTables Editor generation.

[Unreleased]: https://github.com/yajra/laravel-datatables-editor/compare/v1.0.0...master
[v1.0.0]: https://github.com/yajra/laravel-datatables-editor/compare/master...v1.0.0
